/*
 * An example demonstrating the operations of some of the ADTs
 */
package abstractdatatypesexample;
import java.util.*;

/**
 *
 * @author Sarah
 */
public class AbstractDataTypesExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Playing with Stack
        Stack myStack = new Stack();
        
        myStack.push("hi");
        myStack.push(1);
        
        int[] myArray = {1, 2};
        myStack.push(myArray);
        
        myStack.push(true);
        myStack.push(2.18);
        
        System.out.println("myStack: " + myStack);
        System.out.println();
        
        System.out.println("myStack.isEmpty(): " + myStack.isEmpty());
        System.out.println("myStack.peek(): " + myStack.peek());
        myStack.pop();
        System.out.println("myStack.pop()");
        System.out.println("myStack.peek(): " + myStack.peek());
        System.out.println();
        
        System.out.println("myStack:" + myStack);
        System.out.println();
        System.out.println();

        
        // Playing with Queue
        PriorityQueue<Integer> myQueue = new PriorityQueue();
        
        myQueue.add(123);
        myQueue.add(456);
        myQueue.add(789);
        
        System.out.println("myQueue: " + myQueue);
        System.out.println();
        
        System.out.println("myQueue.isEmpty(): " + myQueue.isEmpty());
        System.out.println("myQueue.peek(): " + myQueue.peek());
        myQueue.remove();
        System.out.println("myQueue.remove()");
        System.out.println("myQueue.peek(): " + myQueue.peek());
        System.out.println();
        
        System.out.println("muQueue " + myQueue);
        System.out.println();
        System.out.println();
        
        
        // Playing with Queue
        ArrayDeque<Double> myDeque = new ArrayDeque();
        
        myDeque.addFirst(761.4);
        
        System.out.println("myDeque: " + myDeque);
        System.out.println();
        
        myDeque.addFirst(1289.0);
        System.out.println("myDeque.addFirst(1289.0)");
        System.out.println("myDeque: " + myDeque);
        System.out.println();
        
        myDeque.addLast(50.3);
        System.out.println("myDeque.addLast(50.3)");
        System.out.println("myDeque: " + myDeque);
        System.out.println();
        
        System.out.println("myDeque.isEmpty(): " + myDeque.isEmpty());
        System.out.println("myDeque.peekFirst(): " + myDeque.peekFirst());
        System.out.println("myDeque.peekLast(): " + myDeque.peekLast());
        System.out.println();
        System.out.println();
        
        
        // Playing with HashMap
        HashMap<String, Integer> myHashMap = new HashMap();
        
        myHashMap.put("a", 1);
        myHashMap.put("b", 2);
        myHashMap.put("c", 3);
        
        System.out.println("myHashMap: " + myHashMap);
        
        System.out.println("myHashMap.get(\"a\"): " + myHashMap.get("a"));
        System.out.println("myHashMap.get(\"b\"): " + myHashMap.get("b"));
        System.out.println("myHashMap.get(\"c\"): " + myHashMap.get("c"));
        System.out.println("myHashMap.get(\"d\"): " + myHashMap.get("d"));
        System.out.println();
        
        System.out.println("myHashMap.containsKey(\"b\"): " + myHashMap.containsKey("b"));
        System.out.println("myHashMap.containsValue(4): " + myHashMap.containsValue(4));
        System.out.println("myHashMap.isEmpty(): " + myHashMap.isEmpty());
        System.out.println("myHashMap.size(): " +  myHashMap.size());
        System.out.println();
        
        myHashMap.remove("a");
        System.out.println("myHashMap.remove(\"a\")");
        System.out.println("myHashMap.size(): " +  myHashMap.size());
        System.out.println("myHashMap: " + myHashMap);
        System.out.println();
        
        myHashMap.clear();
        System.out.println("myHashMap.clear()");
        System.out.println("myHashMap: " + myHashMap);
        System.out.println();
        System.out.println();
        
        
        // Playing with HashSet
        HashSet<String> myHashSet = new HashSet();
                
        myHashSet.add("boat");
        myHashSet.add("car");
        myHashSet.add("train");
        myHashSet.add("bike");
        myHashSet.add("car");
        
        
        System.out.println("myHashSet: " + myHashSet);
        
        System.out.println("myHashSet.contains(\"bike\"): " + myHashSet.contains("bike"));
        System.out.println("myHashSet.contains(\"llama\"): " + myHashSet.contains("llama"));
        System.out.println();
        
        System.out.println("myHashSet.isEmpty(): " + myHashSet.isEmpty());
        System.out.println("myHashSet.size(): " +  myHashSet.size());
        System.out.println();
        
        myHashSet.remove("car");
        System.out.println("myHashSet.remove(\"car\")");
        System.out.println("myHashSet.size(): " +  myHashSet.size());
        System.out.println("myHashSet: " + myHashSet);
        System.out.println();
        
        myHashSet.clear();
        System.out.println("myHashSet.clear()");
        System.out.println("myHashSet: " + myHashSet);
    }
    
}
