/*
 * An example showing the structure of a switch statement
 */
package pkgswitch.example;

/**
 *
 * @author Sarah
 */
public class SwitchExample {
 
    // provinceName is a Canadian province or territory's two-letter abbreviation
    public static String provinceName = "QC";

    // regionName is the province or territory's category using the four-region model
    public static String regionName;
    
    /**
     * @param args the command line arguments
     */    
    public static void main(String[] args) {

        switch(provinceName) {
    
            case "BC":
            case "AB":
            case "SK":
            case "MB":
                regionName = "Western Canada";
                break;
            case "ON":
            case "QC":
               regionName = "Central Canada";
                break;
            case "NB":
            case "PE":
            case "NS":
            case "NL":
                regionName = "Atlantic Canada";
                break;    
            case "YT":
            case "NT":
            case "NU":
                regionName = "Northern Canada";
                break; 
            default:
                regionName = "Not a region in Canada";

        }
        
        System.out.println(regionName);
        
    }
    
}
