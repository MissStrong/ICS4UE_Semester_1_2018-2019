/*
 * Assignment 4
 */
package shapes;

/**
 *
 * @author anonymous
 */
public class Triangle {
    
    /*
     * Fill in the documentation here
     */
    public static double area(double b, double h) {
        /*
         * Figure out what goes here
         */   
    }
 
    /**
     * This method takes the side lengths of a triangle and returns the triangle's perimeter.
     * @param a the first side length of the triangle
     * @param b the second side length of the triangle
     * @param c the third side length of the triangle
     * @return the perimeter of the triangle with side lengths a, b, and c
     */ 
    public static double perimeter(double a, double b, double c) {
        return a + b + c;
    }
    
}